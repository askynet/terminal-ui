// components/JobLogs.tsx
export default function JobLogs({ logs }: { logs: any[];}) {
  return (
    <div
      style={{
        background: "#0d1117",
        color: "#c9d1d9",
        padding: 16,
        height: 300,
        overflowY: "auto",
        borderRadius: 6
      }}
    >
      {logs.length === 0 && <p>No logs yet…</p>}
      {logs.map((line, i) => (
        <div key={i}>$ {line}</div>
      ))}
    </div>
  );
}
