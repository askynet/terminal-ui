import { JobState } from "../types/job";

// components/JobHeader.tsx
export default function JobHeader({ job }: { job: JobState;}) {
  return (
    <div style={{ borderBottom: "1px solid #ddd", marginBottom: 16 }}>
      <h2>Legacy Binary Execution</h2>
      <p>Status: <b>{job?.status || "IDLE"}</b></p>
    </div>
  );
}
