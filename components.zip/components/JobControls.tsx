import { JobState } from "../types/job";

// components/JobControls.tsx
export default function JobControls({ job, onStart }: { job: JobState; onStart: () => void }) {
  return (
    <div style={{ marginBottom: 20 }}>
      {!job && (
        <button onClick={onStart}>▶ Run Workflow</button>
      )}

      {job?.status === "RUNNING" && (
        <button style={{ color: "red" }}>⛔ Cancel</button>
      )}
    </div>
  );
}
