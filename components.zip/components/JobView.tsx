// components/JobView.tsx
'use client';

import { useEffect, useState } from "react";
import * as api from "../api";
import JobHeader from "./JobHeader";
import JobSteps from "./JobSteps";
import JobLogs from "./JobLogs";
import JobControls from "./JobControls";

export default function JobView() {
    const [job, setJob] = useState<any>(null);

    const start = async () => {
        const s = await api.start();
        setJob(s);
    };

    // Poll job status
    useEffect(() => {
        if (!job || job.status !== "RUNNING") return;

        const i = setInterval(async () => {
            const updated = await api.get(job.id);
            setJob(updated);
        }, 2000);

        return () => clearInterval(i);
    }, [job?.status]);

    return (
        <div style={{ maxWidth: 900, margin: "40px auto", fontFamily: "monospace" }}>
            <JobHeader job={job} />
            <JobControls job={job} onStart={start} />
            {job && (
                <>
                    <JobSteps job={job} />
                    <JobLogs logs={job.logs || []} />
                </>
            )}
        </div>
    );
}
