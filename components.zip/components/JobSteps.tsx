import { JobState } from "../types/job";

// components/JobSteps.tsx
const steps = [
    "COLLECT_GROUP",
    "COLLECT_VERSION",
    "COLLECT_BOOK",
    "EXECUTE",
    "COMPLETED"
];

export default function JobSteps({ job }: { job: JobState }) {
    return (
        <div style={{ marginBottom: 20 }}>
            {steps.map(step => (
                <div key={step}>
                    {step === job.step ? "⏳" : "✓"} {step}
                </div>
            ))}
        </div>
    );
}
