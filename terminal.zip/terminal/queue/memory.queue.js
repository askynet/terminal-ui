class MemoryQueue {
    constructor() {
        this.queue = [];
        this.running = false;
    }

    enqueue(job) {
        this.queue.push(job);
        this.run();
    }

    async run() {
        if (this.running || !this.queue.length) return;
        this.running = true;

        const job = this.queue.shift();
        try {
            await job.execute();
        } catch (e) {
            if (job.retries-- > 0) this.queue.push(job);
            else job.onFail(e);
        }

        this.running = false;
        this.run();
    }

    cancel() { }
}

module.exports = new MemoryQueue();
