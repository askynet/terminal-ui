const CONFIG = require("../../config/config");

module.exports =
  CONFIG.MODE === "redis"
    ? require("./redis.queue")
    : require("./memory.queue");
