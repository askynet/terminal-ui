const executor = require("../shared/binary.executor");
const queue = require("../queue");
const { CONFIG } = require("../../config/config");

const execute = ({ input }) =>
  new Promise((resolve, reject) => {
    queue.enqueue({
      retries: CONFIG.RETRIES,
      execute: async () => {
        const r = await executor.run({
          input,
          timeout: CONFIG.TIMEOUT
        });
        resolve(r);
      },
      onFail: reject
    });
  });

module.exports = { execute };
