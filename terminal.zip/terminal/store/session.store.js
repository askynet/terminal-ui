const { STEPS } = require("../../config/config");

const sessions = new Map();

exports.create = () => {
  const id = crypto.randomUUID();
  sessions.set(id, { id, data: {}, step: STEPS.ORDER, status: "ACTIVE" });
  return sessions.get(id);
};

exports.get = (id) => sessions.get(id);
exports.update = (id, data) => Object.assign(sessions.get(id), data);
