const store = require("../store/session.store");
const exec = require("../services/execution.service");
const { STEPS } = require("../../config/config");

/**
 * Start session
 */
exports.start = (_, res) => {
    const session = store.create();
    res.json(session);
};

/**
 * Get session
 */
exports.get = (req, res) => {
    const session = store.get(req.params.id);
    res.json(session);
};

/**
 * Step 1: Order
 */
exports.order = async (req, res) => {
    const session = store.get(req.params.id);
    if (session.step !== STEPS.ORDER) {
        return res.status(400).json({ error: "Invalid step" });
    }

    store.update(req.params.id, {
        step: STEPS.EXECUTE
    });

    // 🔥 EXECUTE BINARY ONLY HERE
    exec.execute({
        sessionId: req.params.id,
        input: `${session.data.group}\n${session.data.version}\n${session.data.book}\n`
    });

    store.update(req.params.id, { step: STEPS.RUNNING });

    res.json(store.get(req.params.id));
};
