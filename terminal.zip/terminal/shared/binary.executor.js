const { spawn } = require("child_process");

exports.run = ({ file, input, timeout }) =>
  new Promise((resolve, reject) => {
    const proc = spawn(file);
    let out = "";

    const t = setTimeout(() => {
      proc.kill("SIGKILL");
      reject("TIMEOUT");
    }, timeout);

    proc.stdin.write(input);
    proc.stdin.end();

    proc.stdout.on("data", d => out += d.toString());
    proc.on("close", () => {
      clearTimeout(t);
      resolve(out);
    });
  });
