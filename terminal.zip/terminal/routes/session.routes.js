// backend/api/routes/session.routes.js
const r = require("express").Router();
const c = require("../controllers/session.controller");

r.post("/sessions", c.start);
r.get("/sessions/:id", c.get)
r.post("/sessions/:id/order", c.group);

module.exports = r;
